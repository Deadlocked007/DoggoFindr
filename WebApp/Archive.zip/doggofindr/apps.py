from django.apps import AppConfig


class DoggofindrConfig(AppConfig):
    name = 'doggofindr'
